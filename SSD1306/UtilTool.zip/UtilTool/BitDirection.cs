﻿namespace SSD1306
{
    public enum BitDirection
    {
        Normal,
        Inverse
    }
}

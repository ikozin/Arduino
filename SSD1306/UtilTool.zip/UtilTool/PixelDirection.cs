﻿using System.ComponentModel;

namespace SSD1306
{
    public enum PixelDirection
    {
        //[Description("LEFT")]
        Left,
        //[Description("TOP")]
        Top
    }
}

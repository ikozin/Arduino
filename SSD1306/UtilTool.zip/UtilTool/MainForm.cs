﻿using System;
using System.Drawing;
using System.Text;
using System.Globalization;
using System.Windows.Forms;

namespace SSD1306
{
    public partial class MainForm : Form
    {
        private const int MAXROW = 8;
        private const int MAXCOL = 8;
        private const string VALUE_FORMAT = ", 0x{0:X2}";

        private Color ColorEmpty = Color.White;
        private Color ColorFilled = Color.DarkGray;
        private int _colCount;
        private int _rowCount;
        private BitDirection _rowDirection;
        private BitDirection _colDirection;
        private PixelDirection _direction;

        public MainForm()
        {
            _direction = PixelDirection.Left;
            _rowDirection = BitDirection.Normal;
            _colDirection = BitDirection.Inverse;
            InitializeComponent();
            comboBoxGroupping.DataSource = Enum.GetValues(typeof(PixelDirection));
            comboBoxRowDirection.DataSource = Enum.GetValues(typeof(BitDirection));
            comboBoxColDirection.DataSource = Enum.GetValues(typeof(BitDirection));
            comboBoxGroupping.SelectedItem = _direction;
            comboBoxRowDirection.SelectedItem = _rowDirection;
            comboBoxColDirection.SelectedItem = _colDirection;
            InitMatrix(MAXCOL, _colDirection, MAXROW, _rowDirection, _direction);
            comboBoxGroupping.SelectedValueChanged += comboBox_SelectedValueChanged;
            comboBoxRowDirection.SelectedValueChanged += comboBox_SelectedValueChanged;
            comboBoxColDirection.SelectedValueChanged += comboBox_SelectedValueChanged;
        }

        private void InitMatrix(int colCount, BitDirection colDirection, int rowCount, BitDirection rowDirection, PixelDirection direction)
        {
            _colCount = colCount;
            _rowCount = rowCount;
            _rowDirection = rowDirection;
            _colDirection = colDirection;
            _direction = direction;

            panelTop.BackColor = _direction == PixelDirection.Top? ColorFilled: SystemColors.Control;
            panelLeft.BackColor = _direction == PixelDirection.Left ? ColorFilled : SystemColors.Control;

            labelLeft.Text = (_rowDirection == BitDirection.Normal ? 0 : _colCount - 1).ToString(CultureInfo.CurrentCulture);
            labelRight.Text = (_rowDirection == BitDirection.Normal ? (_colCount - 1): 0).ToString(CultureInfo.CurrentCulture);

            labelTop.Text = (_colDirection == BitDirection.Normal ? 0 : (_rowCount - 1)).ToString(CultureInfo.CurrentCulture);
            labelBottom.Text = (_colDirection == BitDirection.Normal ? (_rowCount - 1) : 0).ToString(CultureInfo.CurrentCulture);

            tableLayoutPixel.SuspendLayout();
            tableLayoutPixel.Controls.Clear();
            tableLayoutPixel.RowStyles.Clear();
            tableLayoutPixel.ColumnStyles.Clear();
            tableLayoutPixel.ColumnCount = _colCount;
            tableLayoutPixel.RowCount = _rowCount;
            tableLayoutPixel.Margin = Padding.Empty;
            tableLayoutPixel.Padding = Padding.Empty;
            for (int col = 0; col < _colCount; col++)
                tableLayoutPixel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / _colCount));
            for (int row = 0; row < _rowCount; row++)
                tableLayoutPixel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / _rowCount));
            tableLayoutPixel.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            for (int row = 0; row < _rowCount; row++)
            {
                for (int col = 0; col < _colCount; col++)
                {
#pragma warning disable CA2000 // Dispose objects before losing scope
                    var panel = new Panel
                    {
                        Dock = DockStyle.Fill,
                        BorderStyle = BorderStyle.FixedSingle,
                        BackColor = ColorEmpty,
                        Margin = Padding.Empty,
                        Tag = (col, row)
                    };
#pragma warning restore CA2000 // Dispose objects before losing scope
                    panel.Click += pixel_Click;
                    tableLayoutPixel.Controls.Add(panel, col, row);
                }
            }
            tableLayoutPixel.ResumeLayout();
        }

        private void pixel_Click(object sender, EventArgs e)
        {
            var panel = (Panel)sender;
            panel.BackColor = panel.BackColor == ColorFilled ? ColorEmpty : ColorFilled;
        }

        private void CollectPixelCol(StringBuilder text)
        {
            int col = _rowDirection == BitDirection.Normal ? 0: _colCount - 1;
            int col_step = _rowDirection == BitDirection.Normal ? 1 : -1;
            for (int x_index = 0; x_index < _colCount; x_index++)
            {
                int row = _colDirection == BitDirection.Normal ? 0 : _rowCount - 1;
                int row_step = _colDirection == BitDirection.Normal ? 1 : -1;
                UInt64 data = 0x00;
                for (int y_index = 0; y_index < _rowCount; y_index++) 
                {
                    var pixel = (Panel)tableLayoutPixel.GetControlFromPosition(col, row);
                    bool value = pixel.BackColor == ColorFilled;
                    if (value)
                    {
                        data |= (UInt64)1 << y_index;
                    }
                    row += row_step;
                }
                col += col_step;
                text.AppendFormat(CultureInfo.CurrentCulture, VALUE_FORMAT, data);
            }
        }
        
        private void CollectPixelRow(StringBuilder text)
        {
            int row = _colDirection == BitDirection.Normal ? 0 : _rowCount - 1;
            int row_step = _colDirection == BitDirection.Normal ? 1 : -1;
            for (int y_index = 0; y_index < _rowCount; y_index++) 
            {
                int col = _rowDirection == BitDirection.Normal ? 0 : _colCount - 1;
                int col_step = _rowDirection == BitDirection.Normal ? 1 : -1;
                UInt64 data = 0x00;
                for (int x_index = 0; x_index < _colCount; x_index++)
                {
                    var pixel = (Panel)tableLayoutPixel.GetControlFromPosition(col, row);
                    bool value = pixel.BackColor == ColorFilled;
                    if (value)
                    {
                        data |= (UInt64)1 << x_index;
                    }
                    col += col_step;
                }
                row += row_step;
                text.AppendFormat(CultureInfo.CurrentCulture, VALUE_FORMAT, data);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            StringBuilder text = new StringBuilder(1024);
            if (_direction == PixelDirection.Left)
            {
                CollectPixelCol(text);
            }
            else
            {
                CollectPixelRow(text);
            }
            text.Remove(0, 2);
            text.Append("};");
            text.Insert(0, String.Format(CultureInfo.CurrentCulture, "const uint8_t {0}[] PROGMEM={{", textBoxName.Text));
            text.AppendLine();
            textBoxResult.Text += text.ToString();
        }

        private void comboBox_SelectedValueChanged(object sender, EventArgs e)
        {
            _direction = (PixelDirection)comboBoxGroupping.SelectedValue;
            _rowDirection = (BitDirection)comboBoxRowDirection.SelectedValue;
            _colDirection = (BitDirection)comboBoxColDirection.SelectedValue;
            InitMatrix(_colCount, _colDirection, _rowCount, _rowDirection, _direction);
        }
    }
}

﻿namespace SSD1306
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnGenerate;
            System.Windows.Forms.GroupBox groupBoxCol;
            System.Windows.Forms.GroupBox groupBoxRow;
            this.tableLayoutPixel = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelDesk = new System.Windows.Forms.TableLayoutPanel();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.panelTopLabel = new System.Windows.Forms.Panel();
            this.labelRight = new System.Windows.Forms.Label();
            this.labelLeft = new System.Windows.Forms.Label();
            this.panelLeftLabel = new System.Windows.Forms.Panel();
            this.labelBottom = new System.Windows.Forms.Label();
            this.labelTop = new System.Windows.Forms.Label();
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.groupBoxFrouping = new System.Windows.Forms.GroupBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.comboBoxGroupping = new System.Windows.Forms.ComboBox();
            this.comboBoxRowDirection = new System.Windows.Forms.ComboBox();
            this.comboBoxColDirection = new System.Windows.Forms.ComboBox();
            btnGenerate = new System.Windows.Forms.Button();
            groupBoxCol = new System.Windows.Forms.GroupBox();
            groupBoxRow = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelDesk.SuspendLayout();
            this.panelTopLabel.SuspendLayout();
            this.panelLeftLabel.SuspendLayout();
            this.groupBoxFrouping.SuspendLayout();
            groupBoxCol.SuspendLayout();
            groupBoxRow.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGenerate
            // 
            btnGenerate.Location = new System.Drawing.Point(338, 55);
            btnGenerate.Name = "btnGenerate";
            btnGenerate.Size = new System.Drawing.Size(118, 44);
            btnGenerate.TabIndex = 8;
            btnGenerate.Text = "Generate";
            btnGenerate.UseVisualStyleBackColor = true;
            btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // tableLayoutPixel
            // 
            this.tableLayoutPixel.ColumnCount = 1;
            this.tableLayoutPixel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPixel.Location = new System.Drawing.Point(43, 43);
            this.tableLayoutPixel.Name = "tableLayoutPixel";
            this.tableLayoutPixel.RowCount = 1;
            this.tableLayoutPixel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPixel.Size = new System.Drawing.Size(256, 256);
            this.tableLayoutPixel.TabIndex = 5;
            // 
            // tableLayoutPanelDesk
            // 
            this.tableLayoutPanelDesk.ColumnCount = 3;
            this.tableLayoutPanelDesk.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelDesk.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelDesk.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 271F));
            this.tableLayoutPanelDesk.Controls.Add(this.tableLayoutPixel, 2, 2);
            this.tableLayoutPanelDesk.Controls.Add(this.panelTop, 2, 0);
            this.tableLayoutPanelDesk.Controls.Add(this.panelLeft, 0, 2);
            this.tableLayoutPanelDesk.Controls.Add(this.panelTopLabel, 2, 1);
            this.tableLayoutPanelDesk.Controls.Add(this.panelLeftLabel, 1, 2);
            this.tableLayoutPanelDesk.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanelDesk.Name = "tableLayoutPanelDesk";
            this.tableLayoutPanelDesk.RowCount = 3;
            this.tableLayoutPanelDesk.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelDesk.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelDesk.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 256F));
            this.tableLayoutPanelDesk.Size = new System.Drawing.Size(299, 302);
            this.tableLayoutPanelDesk.TabIndex = 6;
            // 
            // panelTop
            // 
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTop.Location = new System.Drawing.Point(43, 3);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(265, 14);
            this.panelTop.TabIndex = 6;
            // 
            // panelLeft
            // 
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLeft.Location = new System.Drawing.Point(3, 43);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(14, 256);
            this.panelLeft.TabIndex = 7;
            // 
            // panelTopLabel
            // 
            this.panelTopLabel.Controls.Add(this.labelRight);
            this.panelTopLabel.Controls.Add(this.labelLeft);
            this.panelTopLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTopLabel.Location = new System.Drawing.Point(43, 23);
            this.panelTopLabel.Name = "panelTopLabel";
            this.panelTopLabel.Size = new System.Drawing.Size(265, 14);
            this.panelTopLabel.TabIndex = 8;
            // 
            // labelRight
            // 
            this.labelRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.labelRight.Location = new System.Drawing.Point(230, 0);
            this.labelRight.Name = "labelRight";
            this.labelRight.Size = new System.Drawing.Size(35, 14);
            this.labelRight.TabIndex = 1;
            this.labelRight.Text = "label2";
            // 
            // labelLeft
            // 
            this.labelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelLeft.Location = new System.Drawing.Point(0, 0);
            this.labelLeft.Name = "labelLeft";
            this.labelLeft.Size = new System.Drawing.Size(35, 14);
            this.labelLeft.TabIndex = 0;
            this.labelLeft.Text = "label1";
            // 
            // panelLeftLabel
            // 
            this.panelLeftLabel.Controls.Add(this.labelBottom);
            this.panelLeftLabel.Controls.Add(this.labelTop);
            this.panelLeftLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLeftLabel.Location = new System.Drawing.Point(23, 43);
            this.panelLeftLabel.Name = "panelLeftLabel";
            this.panelLeftLabel.Size = new System.Drawing.Size(14, 256);
            this.panelLeftLabel.TabIndex = 9;
            // 
            // labelBottom
            // 
            this.labelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelBottom.Location = new System.Drawing.Point(0, 243);
            this.labelBottom.Name = "labelBottom";
            this.labelBottom.Size = new System.Drawing.Size(14, 13);
            this.labelBottom.TabIndex = 1;
            this.labelBottom.Text = "label4";
            // 
            // labelTop
            // 
            this.labelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelTop.Location = new System.Drawing.Point(0, 0);
            this.labelTop.Name = "labelTop";
            this.labelTop.Size = new System.Drawing.Size(14, 13);
            this.labelTop.TabIndex = 0;
            this.labelTop.Text = "label3";
            // 
            // textBoxResult
            // 
            this.textBoxResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxResult.Location = new System.Drawing.Point(462, 17);
            this.textBoxResult.Multiline = true;
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxResult.Size = new System.Drawing.Size(558, 306);
            this.textBoxResult.TabIndex = 7;
            this.textBoxResult.WordWrap = false;
            // 
            // groupBoxFrouping
            // 
            this.groupBoxFrouping.Controls.Add(this.comboBoxGroupping);
            this.groupBoxFrouping.Location = new System.Drawing.Point(319, 105);
            this.groupBoxFrouping.Name = "groupBoxFrouping";
            this.groupBoxFrouping.Size = new System.Drawing.Size(137, 54);
            this.groupBoxFrouping.TabIndex = 9;
            this.groupBoxFrouping.TabStop = false;
            this.groupBoxFrouping.Text = "Группировка";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(338, 29);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(118, 20);
            this.textBoxName.TabIndex = 12;
            this.textBoxName.Text = "value";
            // 
            // comboBoxGroupping
            // 
            this.comboBoxGroupping.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGroupping.FormattingEnabled = true;
            this.comboBoxGroupping.Location = new System.Drawing.Point(6, 19);
            this.comboBoxGroupping.Name = "comboBoxGroupping";
            this.comboBoxGroupping.Size = new System.Drawing.Size(121, 21);
            this.comboBoxGroupping.TabIndex = 14;
            // 
            // comboBoxRowDirection
            // 
            this.comboBoxRowDirection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRowDirection.FormattingEnabled = true;
            this.comboBoxRowDirection.Location = new System.Drawing.Point(6, 19);
            this.comboBoxRowDirection.Name = "comboBoxRowDirection";
            this.comboBoxRowDirection.Size = new System.Drawing.Size(121, 21);
            this.comboBoxRowDirection.TabIndex = 15;
            // 
            // comboBoxColDirection
            // 
            this.comboBoxColDirection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxColDirection.FormattingEnabled = true;
            this.comboBoxColDirection.Location = new System.Drawing.Point(6, 19);
            this.comboBoxColDirection.Name = "comboBoxColDirection";
            this.comboBoxColDirection.Size = new System.Drawing.Size(121, 21);
            this.comboBoxColDirection.TabIndex = 16;
            // 
            // groupBoxCol
            // 
            groupBoxCol.Controls.Add(this.comboBoxColDirection);
            groupBoxCol.Location = new System.Drawing.Point(319, 225);
            groupBoxCol.Name = "groupBoxCol";
            groupBoxCol.Size = new System.Drawing.Size(137, 54);
            groupBoxCol.TabIndex = 17;
            groupBoxCol.TabStop = false;
            groupBoxCol.Text = "Col";
            // 
            // groupBoxRow
            // 
            groupBoxRow.Controls.Add(this.comboBoxRowDirection);
            groupBoxRow.Location = new System.Drawing.Point(319, 165);
            groupBoxRow.Name = "groupBoxRow";
            groupBoxRow.Size = new System.Drawing.Size(137, 54);
            groupBoxRow.TabIndex = 18;
            groupBoxRow.TabStop = false;
            groupBoxRow.Text = "Row";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 336);
            this.Controls.Add(groupBoxRow);
            this.Controls.Add(groupBoxCol);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.groupBoxFrouping);
            this.Controls.Add(btnGenerate);
            this.Controls.Add(this.textBoxResult);
            this.Controls.Add(this.tableLayoutPanelDesk);
            this.Name = "MainForm";
            this.Text = "Pixel";
            this.tableLayoutPanelDesk.ResumeLayout(false);
            this.panelTopLabel.ResumeLayout(false);
            this.panelLeftLabel.ResumeLayout(false);
            this.groupBoxFrouping.ResumeLayout(false);
            groupBoxCol.ResumeLayout(false);
            groupBoxRow.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPixel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelDesk;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panelTopLabel;
        private System.Windows.Forms.Label labelRight;
        private System.Windows.Forms.Label labelLeft;
        private System.Windows.Forms.Panel panelLeftLabel;
        private System.Windows.Forms.Label labelBottom;
        private System.Windows.Forms.Label labelTop;
        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.GroupBox groupBoxFrouping;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.ComboBox comboBoxGroupping;
        private System.Windows.Forms.ComboBox comboBoxRowDirection;
        private System.Windows.Forms.ComboBox comboBoxColDirection;
    }
}


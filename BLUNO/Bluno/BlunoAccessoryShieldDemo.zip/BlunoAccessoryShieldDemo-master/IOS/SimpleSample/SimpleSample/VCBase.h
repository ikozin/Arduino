//
//  VCBase.h
//  SimpleSample
//
//  Created by Seifer on 13-10-15.
//  Copyright (c) 2013年 DFRobot. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VCMain.h"

@interface VCBase : UIViewController

@end

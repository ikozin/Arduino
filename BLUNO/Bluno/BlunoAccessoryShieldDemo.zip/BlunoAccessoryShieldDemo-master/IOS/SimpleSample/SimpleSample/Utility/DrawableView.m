//
//  DrawableView.m
//  SimpleSample
//
//  Created by Seifer on 13-10-16.
//  Copyright (c) 2013年 DFRobot. All rights reserved.
//

#import "DrawableView.h"

@implementation DrawableView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect
{
    // Drawing code
}


@end

//
//  DrawableView.h
//  SimpleSample
//
//  Created by Seifer on 13-10-16.
//  Copyright (c) 2013年 DFRobot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawableView : UIView

@end

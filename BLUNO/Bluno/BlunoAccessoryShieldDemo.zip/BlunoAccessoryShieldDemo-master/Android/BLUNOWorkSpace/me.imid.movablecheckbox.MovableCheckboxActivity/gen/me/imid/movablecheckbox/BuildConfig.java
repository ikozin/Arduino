/** Automatically generated file. DO NOT MODIFY */
package me.imid.movablecheckbox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
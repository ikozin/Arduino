SwitchButton
============

类似IOS上的SwitchButton 支持滑动和动画
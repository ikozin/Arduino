#ifndef _MP1051_H_
#define _MP1051_H_

#include <Arduino.h>

class MP1051Class
{
public:
  static void Init();
  static void Set(byte D1, byte D2, byte D3, byte D4, byte D5, byte D6, byte D7, byte D8);
  static void Brightness(byte B);
  static byte IR(int T);
  static byte IRAdr();
  static byte IRData();
private:
  static byte IRWait(int T);
  static byte IRBit();
  static byte IRRead();
};

extern MP1051Class MP1051;

#endif
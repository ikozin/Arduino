﻿#define DEMO
using System;
using System.Collections.Generic;
using System.Threading;

namespace ConsoleApp
{
    class Program
    {
        const char EmptyCell = ' ';
        const char FilledCell = '*';

        #region SCREEN
        static readonly char[,] _screen =
        {
#if DEMO
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
#else
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
            { EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, EmptyCell, },
#endif
        };
        #endregion

        #region BLOCK
        static readonly byte[] _blocks =
        {
            /////////////////////////////////////////
            //
            // **
            // **
            //
            /////////////////////////////////////////
            0b0000_1100,
            0b0000_1100,
            0b0000_0000,
            0b0000_0000,

            0b0000_1100,
            0b0000_1100,
            0b0000_0000,
            0b0000_0000,

            0b0000_1100,
            0b0000_1100,
            0b0000_0000,
            0b0000_0000,

            0b0000_1100,
            0b0000_1100,
            0b0000_0000,
            0b0000_0000,

            /////////////////////////////////////////
            // *
            // **
            //  *
            //
            /////////////////////////////////////////
            0b0000_1000,
            0b0000_1100,
            0b0000_0100,
            0b0000_0000,

            0b0000_0110,
            0b0000_1100,
            0b0000_0000,
            0b0000_0000,

            0b0000_1000,
            0b0000_1100,
            0b0000_0100,
            0b0000_0000,

            0b0000_0110,
            0b0000_1100,
            0b0000_0000,
            0b0000_0000,

            /////////////////////////////////////////
            //  *
            // **
            // *
            //
            /////////////////////////////////////////
            0b0000_0100,
            0b0000_1100,
            0b0000_1000,
            0b0000_0000,

            0b0000_1100,
            0b0000_0110,
            0b0000_0000,
            0b0000_0000,

            0b0000_0100,
            0b0000_1100,
            0b0000_1000,
            0b0000_0000,

            0b0000_1100,
            0b0000_0110,
            0b0000_0000,
            0b0000_0000,

            /////////////////////////////////////////
            //  *
            //  *
            //  *
            //  *
            /////////////////////////////////////////
            0b0000_0100,
            0b0000_0100,
            0b0000_0100,
            0b0000_0100,

            0b0000_0000,
            0b0000_1111,
            0b0000_0000,
            0b0000_0000,

            0b0000_0100,
            0b0000_0100,
            0b0000_0100,
            0b0000_0100,

            0b0000_0000,
            0b0000_1111,
            0b0000_0000,
            0b0000_0000,


            /////////////////////////////////////////
            //  *
            // **
            //  *
            // 
            /////////////////////////////////////////
            0b0000_0100,
            0b0000_1100,
            0b0000_0100,
            0b0000_0000,

            0b0000_0000,
            0b0000_1110,
            0b0000_0100,
            0b0000_0000,

            0b0000_0100,
            0b0000_0110,
            0b0000_0100,
            0b0000_0000,

            0b0000_0100,
            0b0000_1110,
            0b0000_0000,
            0b0000_0000,

            /////////////////////////////////////////
            // **
            //  *
            //  *
            // 
            /////////////////////////////////////////
            0b0000_1100,
            0b0000_0100,
            0b0000_0100,
            0b0000_0000,

            0b0000_0000,
            0b0000_1110,
            0b0000_1000,
            0b0000_0000,

            0b0000_0100,
            0b0000_0100,
            0b0000_0110,
            0b0000_0000,

            0b0000_0010,
            0b0000_1110,
            0b0000_0000,
            0b0000_0000,

            /////////////////////////////////////////
            //  **
            //  *
            //  *
            // 
            /////////////////////////////////////////
            0b0000_0110,
            0b0000_0100,
            0b0000_0100,
            0b0000_0000,

            0b0000_1000,
            0b0000_1110,
            0b0000_0000,
            0b0000_0000,

            0b0000_0100,
            0b0000_0100,
            0b0000_1100,
            0b0000_0000,

            0b0000_0000,
            0b0000_1110,
            0b0000_0010,
            0b0000_0000,
        };
        #endregion

        static readonly int _delay = 50;
        static byte _block = 0;
        static byte _slide = 0;
        static byte _x = 0;
        static byte _y = 0;
        static readonly byte maxX = (byte)_screen.GetLength(1);
        static readonly byte maxY = (byte)_screen.GetLength(0);
        static readonly Random _rnd = new Random(DateTime.Now.Millisecond);

        static readonly Dictionary<ConsoleKey, Func<bool>> _actionMapping = new Dictionary<ConsoleKey, Func<bool>>
        {
            { ConsoleKey.LeftArrow, moveBlockToLeft },
            { ConsoleKey.RightArrow, moveBlockToRight },
            { ConsoleKey.UpArrow, rotateBlockToLeft },
            { ConsoleKey.DownArrow, rotateBlockToRight },
            { ConsoleKey.Spacebar, dropBlock },
        };

        static void Main(string[] args)
        {
            newBlock();
            for (; ; )
            {
                if (!clearBlock(_block, _slide, _x, _y)) break;
                if (!proceedAction()) break;
                if (!showBlock(_block, _slide, _x, _y)) break;
                //DropLines();
                diplayScreen();
                Thread.Sleep(_delay);
            }
        }

        static void diplayScreen()
        {
            Console.Clear();
            Console.Write('╔');
            for (int x = 0; x < maxX; x++) Console.Write('═');
            Console.WriteLine('╗');
            for (int y = 0; y < maxY; y++)
            {
                Console.Write('║');
                for (int x = 0; x < maxX; x++) Console.Write(_screen[y, x]);
                Console.WriteLine('║');
            }
            Console.Write('╚');
            for (int x = 0; x < maxX; x++) Console.Write('═');
            Console.WriteLine('╝');
        }

        static bool clearBlock(byte blockIndex, byte slideIndex, byte x, byte y)
        {
            return actionBlock(blockIndex, slideIndex, x, y, false, false);
        }

        static bool showBlock(byte blockIndex, byte slideIndex, byte x, byte y)
        {
            return actionBlock(blockIndex, slideIndex, x, y, true, false);
        }

        static bool checkBlock(byte blockIndex, byte slideIndex, byte x, byte y)
        {
            return actionBlock(blockIndex, slideIndex, x, y, true, true);
        }

        static bool actionBlock(byte blockIndex, byte slideIndex, byte x, byte y, bool show, bool check)
        {
            byte index = (byte)((blockIndex << 4) + (slideIndex << 2));
            byte posY = y;

            for (byte row = 0; row < 4; row++)
            {
                byte posX = x;
                for (byte mask = 0b0000_1000; mask > 0; mask >>= 1)
                {
                    if ((_blocks[index] & mask) > 0)
                    {
                        if (posX < 0 || posY < 0) return false;
                        if (posX >= maxX || posY >= maxY) return false;
                        if (show && _screen[posY, posX] != EmptyCell) return false;
                        if (!check)
                            _screen[posY, posX] = show ? FilledCell : EmptyCell;
                    }
                    posX++;
                }
                posY++;
                index++;
            }
            return true;
        }

        static void newBlock()
        {
            dropLines();
            _x = (byte)((maxX >> 1) - 1);
            _y = 0;
            _block = (byte)_rnd.Next(7);
            _slide = (byte)_rnd.Next(4);
        }

        static bool moveBlockToLeft()
        {
            byte posX = (byte)(_x - 1);
            if (checkBlock(_block, _slide, posX, _y)) _x = posX;
            return true;
        }

        static bool moveBlockToRight()
        {
            byte posX = (byte)(_x + 1);
            if (checkBlock(_block, _slide, posX, _y)) _x = posX;
            return true;
        }

        static bool rotateBlockToLeft()
        {
            byte nextSlide = (byte)((_slide + 1) % 4);
            if (checkBlock(_block, nextSlide, _x, _y)) _slide = nextSlide;
            return true;
        }

        static bool rotateBlockToRight()
        {
            byte nextSlide = (byte)((_slide - 1) % 4);
            if (checkBlock(_block, nextSlide, _x, _y)) _slide = nextSlide;
            return true;
        }

        static bool dropBlock()
        {
            for (; ; )
            {
                byte posY = (byte)(_y + 1);
                if (!checkBlock(_block, _slide, _x, posY)) break;
                _y = posY;
            }
            showBlock(_block, _slide, _x, _y);
            newBlock();
            return true;
        }

        static bool dropLines()
        {

            for (int y = 0; y < maxY; y++)
            {
                int counter = 0;
                for (int x = 0; x < maxX; x++)
                    counter += _screen[y, x] == FilledCell ? 1 : 0;
                if (counter == maxX)
                {
                    for (int x = 0; x < maxX; x++) _screen[y, x] = EmptyCell;
                    for (int n = y - 1; n > 0; n--)
                    {
                        for (int x = 0; x < maxX; x++) _screen[n + 1, x] = _screen[n, x];
                    }
                }
            }
            return true;
        }

        static bool proceedAction()
        {
            if (!Console.KeyAvailable) return true;
            var key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.Escape) return false;

            if (_actionMapping.ContainsKey(key.Key))
                return _actionMapping[key.Key]();
            return true;
        }
    }
}
